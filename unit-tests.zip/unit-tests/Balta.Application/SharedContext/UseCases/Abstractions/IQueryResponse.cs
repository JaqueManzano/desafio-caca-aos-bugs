namespace Balta.Application.SharedContext.UseCases.Abstractions;

public interface IQueryResponse;