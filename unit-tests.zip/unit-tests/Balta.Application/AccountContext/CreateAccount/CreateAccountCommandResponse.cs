using Balta.Application.SharedContext.UseCases.Abstractions;

namespace Balta.Application.AccountContext.CreateAccount;

public record CreateAccountCommandResponse : ICommandResponse;