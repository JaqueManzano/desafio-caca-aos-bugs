﻿namespace Balta.Domain.Test
{
    public class PasswordTestCase
    {
        public string PlainText { get; set; }
        public bool? IsValid { get; set; } 
    }
}
