﻿namespace Balta.Domain.Test.Command.Interface
{
    public interface ICommand
    {
        void Validate();
    }
}
