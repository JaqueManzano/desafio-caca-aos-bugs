namespace Balta.Domain.AccountContext.Entities;

public class Exam
{
    public string Title { get; set; }
    public string Questions { get; set; }
}