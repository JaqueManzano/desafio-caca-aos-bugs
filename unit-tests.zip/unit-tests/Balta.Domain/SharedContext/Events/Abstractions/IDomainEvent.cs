using MediatR;

namespace Balta.Domain.SharedContext.Events.Abstractions;

public interface IDomainEvent : INotification;