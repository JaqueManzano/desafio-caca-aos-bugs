namespace Balta.Domain.SharedContext.Aggregates.Abstractions;

public interface IAggregateRoot;