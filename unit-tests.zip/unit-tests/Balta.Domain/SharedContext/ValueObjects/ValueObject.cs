namespace Balta.Domain.SharedContext.ValueObjects;

public abstract record ValueObject;