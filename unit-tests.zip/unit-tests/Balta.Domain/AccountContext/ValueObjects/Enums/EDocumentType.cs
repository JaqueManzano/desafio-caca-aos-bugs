namespace Balta.Domain.AccountContext.ValueObjects.Enums;

public enum EDocumentType
{
    Person = 1,
    Company = 2,
    Foreigner = 3,
}