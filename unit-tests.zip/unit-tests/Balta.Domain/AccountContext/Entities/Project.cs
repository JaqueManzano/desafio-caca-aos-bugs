namespace Balta.Domain.AccountContext.Entities;

public class Project
{
    public string Title { get; set; }
}