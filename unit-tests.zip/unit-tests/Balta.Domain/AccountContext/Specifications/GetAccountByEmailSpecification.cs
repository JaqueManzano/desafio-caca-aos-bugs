namespace Balta.Domain.AccountContext.Specifications;

public record GetAccountByEmailSpecification();