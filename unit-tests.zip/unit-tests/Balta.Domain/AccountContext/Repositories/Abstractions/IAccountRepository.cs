namespace Balta.Domain.AccountContext.Repositories.Abstractions;

public interface IAccountRepository;